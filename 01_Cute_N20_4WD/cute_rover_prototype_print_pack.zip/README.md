# Cute N20 4WD prototype print pack

Geometry-validated prototype assets; exact hardware fit and physical printer tests remain UNVERIFIED.

Print ONLY exports/*.stl after reading audit/PRINT_GUIDE.md. The 12 files contain 11 vehicle part types plus an optional fit coupon. standoffs.stl contains four spacers. Quantities/orientations are in audit/printable_parts.csv.

Do not print the complete assembly: parts/assembly.scad and the master default show generic motor envelopes and assembled touching components. No complete-assembly STL is included in this print pack.

Wheel bolts require 14 mm effective under-head length (M3x14, or M3x16 with 2 mm head-side spacers), heads outboard, tips flush inboard. Radial locks use HEADLESS M3 grub screws. Inspect real shaft engagement, nut/thread fit and 0.5 mm saddle-nose clearance.

Authoritative master and all part wrappers are included. Export units are millimetres. Camera/ToF faces and wheel pocket already have practical print orientations.

The complete CAD audit, original preserved files, reproducible scripts and numerical evidence remain in the workspace at 01_Cute_N20_4WD/audit/CAD_AUDIT.md. Root artwork is conceptual and excluded from this print pack.
